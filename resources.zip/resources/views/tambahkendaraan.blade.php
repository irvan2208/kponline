@extends('layouts.master')
@section('title','Kendaraan')
@section('page-header','Tambah Kendaraan')
@section('page-description','Silahkan isi form berikut')
@section('breadcrumblv2')
<li class="active">Tambah Kendaraan</li>
@endsection

@section('content')
<section class="content">
	<div class="box box-primary">
		<div class="box-body">
			sdf
		</div>
	</div>
</section>

@endsection