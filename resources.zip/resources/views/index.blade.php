@extends('layouts.master')
@section('title','Utama')
@section('page-header','Pembayaran Member Parkir UIB')
@section('page-description','Silahkan isi form berikut')
@section('breadcrumblv2')
<li class="active">Pembayaran</li>
@endsection

@section('content')

<section class="content">
      <div class="box box-primary">
        <div class="box-body" style="display: block;">
          body

        </div>
        <div class="box-footer">
          Footer
        </div>
      </div>
</section>
@endsection